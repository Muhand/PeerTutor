const express = require('express');
const app = express();

//Home Page
app.get('/', function(req, res){
  res.send('Welcome to homepage');
});

//Login
app.get('/login', function(req, res){
   res.send("Login Page"); 
});

//SignUp
app.get('/signup', function(req, res){
   res.send("Signup Page"); 
});

//Load the tutors controller
const tutors = require('./controllers/tutors');
app.use('/tutors', tutors);

app.listen(8080);