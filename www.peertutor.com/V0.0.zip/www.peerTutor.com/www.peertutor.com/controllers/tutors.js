var express = require('express');
var router = express.Router();

// middleware that is specific to this router (We did not cover this in class)
// It applies to all routes defined in this controller
router.use(function timeLog(req, res, next) {
  console.log('Tutors Controller :: Time: ', Date.now());
  next();
});


// define the root articles route
router.get('/', function(req, res) {
  res.send('Tutors home page');
});

// define the specific article route
// Note: 'slug' is how we refer to document titles in url's
// For some history checkout: http://stackoverflow.com/a/4230937
router.get('/:first', function(req, res) {
  res.send('The firsttutor is: ' + req.params.first);
});

router.get('/:first/:last', function(req, res) {
  res.send('The lasttutor is: ' + req.params.last + '\nFirst tutor is: ' + req.params.first);
});

module.exports = router;